(function($) {
    $(document).ready(function() {
        console.log('Jaroncito ElementAddons script loaded.');
    });
})(jQuery);
